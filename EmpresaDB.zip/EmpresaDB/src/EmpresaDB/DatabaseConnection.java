package EmpresaDB;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/empresa_db";
        String user = "admin";
        String password = "182528";
        return DriverManager.getConnection(url, user, password);
    }
}
