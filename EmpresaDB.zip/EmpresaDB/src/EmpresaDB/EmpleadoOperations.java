package EmpresaDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmpleadoOperations {

    public void mostrarEmpleadosDesarrollo() {
        String sql = "SELECT Nombre, Salario FROM Empleado WHERE DepartamentoID = 2 AND Salario > 60000.00";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                System.out.println("Nombre: " + rs.getString("Nombre") + ", Salario: " + rs.getDouble("Salario"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void agregarDepartamento() {
        String sql = "INSERT INTO Departamento (DepartamentoID, Nombre, Ubicacion) VALUES (4, 'Marketing', 'Piso 4, Edificio D')";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.executeUpdate();
            System.out.println("Departamento agregado exitosamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void actualizarSalarioJuan() {
        String sql = "UPDATE Empleado SET Salario = Salario * 1.10 WHERE Nombre = 'Juan Pérez' AND Cargo = 'Vendedor'";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.executeUpdate();
            System.out.println("Salario actualizado exitosamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminarEmpleado() {
        String sql = "DELETE FROM Empleado WHERE EmpleadoID = 105";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.executeUpdate();
            System.out.println("Empleado eliminado exitosamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
