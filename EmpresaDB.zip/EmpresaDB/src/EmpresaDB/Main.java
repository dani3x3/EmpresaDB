package EmpresaDB;

public class Main {
    public static void main(String[] args) {
        EmpleadoOperations ops = new EmpleadoOperations();

        // Mostrar empleados del departamento de Desarrollo con salario mayor a 60000.00
        ops.mostrarEmpleadosDesarrollo();

        // Agregar un nuevo departamento
        ops.agregarDepartamento();

        // Actualizar el salario de Juan Pérez
        ops.actualizarSalarioJuan();

        // Eliminar al empleado con ID 105
        ops.eliminarEmpleado();
    }
}
